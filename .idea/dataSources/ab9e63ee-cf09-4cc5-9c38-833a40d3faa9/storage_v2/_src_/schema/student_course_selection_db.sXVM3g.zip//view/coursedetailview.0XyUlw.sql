create definer = root@localhost view coursedetailview as
select `c`.`course_id`                                                             AS `course_id`,
       `c`.`course_name`                                                           AS `course_name`,
       `c`.`credit`                                                                AS `credit`,
       `c`.`max_students`                                                          AS `max_students`,
       `t`.`teacher_id`                                                            AS `teacher_id`,
       `t`.`name`                                                                  AS `teacher_name`,
       `t`.`title`                                                                 AS `teacher_title`,
       `c`.`type_code`                                                             AS `type_code`,
       `cat`.`type_name`                                                           AS `course_type`,
       `cat`.`credit_requirement`                                                  AS `credit_requirement`,
       count(distinct `e`.`student_id`)                                            AS `current_enrollment`,
       (`c`.`max_students` - count(distinct `e`.`student_id`))                     AS `available_seats`,
       round(((count(distinct `e`.`student_id`) * 100.0) / `c`.`max_students`), 2) AS `enrollment_rate`,
       `sch`.`week_day`                                                            AS `week_day`,
       `sch`.`start_time`                                                          AS `start_time`,
       `sch`.`end_time`                                                            AS `end_time`,
       `sch`.`location`                                                            AS `location`
from ((((`student_course_selection_db`.`course` `c` join `student_course_selection_db`.`teacher` `t`
         on ((`c`.`teacher_id` = `t`.`teacher_id`))) left join `student_course_selection_db`.`course_categories` `cat`
        on ((`c`.`type_code` = `cat`.`type_code`))) left join `student_course_selection_db`.`enrollment` `e`
       on ((`c`.`course_id` = `e`.`course_id`))) left join `student_course_selection_db`.`schedule` `sch`
      on ((`c`.`course_id` = `sch`.`course_id`)))
group by `c`.`course_id`, `c`.`course_name`, `c`.`credit`, `c`.`max_students`, `t`.`teacher_id`, `t`.`name`,
         `t`.`title`, `c`.`type_code`, `cat`.`type_name`, `cat`.`credit_requirement`, `sch`.`week_day`,
         `sch`.`start_time`, `sch`.`end_time`, `sch`.`location`;

-- comment on column coursedetailview.type_code not supported: 课程类型代码

