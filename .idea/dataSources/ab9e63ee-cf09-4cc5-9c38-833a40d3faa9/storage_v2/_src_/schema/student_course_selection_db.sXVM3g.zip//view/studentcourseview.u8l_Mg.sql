create definer = root@localhost view studentcourseview as
select `s`.`student_id`        AS `student_id`,
       `s`.`name`              AS `student_name`,
       `c`.`course_id`         AS `course_id`,
       `c`.`course_name`       AS `course_name`,
       `c`.`credit`            AS `credit`,
       `t`.`name`              AS `teacher_name`,
       count(`e`.`student_id`) AS `enrolled_students`,
       `c`.`max_students`      AS `max_students`,
       (case
            when exists(select 1
                        from `student_course_selection_db`.`enrollment`
                        where ((`student_course_selection_db`.`enrollment`.`student_id` = `s`.`student_id`) and
                               (`student_course_selection_db`.`enrollment`.`course_id` = `c`.`course_id`))) then '已选'
            else '未选' end)   AS `enrollment_status`
from (((`student_course_selection_db`.`student` `s` join `student_course_selection_db`.`course` `c`) join `student_course_selection_db`.`teacher` `t`
       on ((`c`.`teacher_id` = `t`.`teacher_id`))) left join `student_course_selection_db`.`enrollment` `e`
      on ((`c`.`course_id` = `e`.`course_id`)))
group by `s`.`student_id`, `c`.`course_id`, `c`.`course_name`, `c`.`credit`, `t`.`name`, `c`.`max_students`;

