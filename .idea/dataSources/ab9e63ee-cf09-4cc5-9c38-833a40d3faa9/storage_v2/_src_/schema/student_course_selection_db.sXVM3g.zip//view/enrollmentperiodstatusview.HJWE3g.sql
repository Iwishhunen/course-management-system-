create definer = root@localhost view enrollmentperiodstatusview as
select `student_course_selection_db`.`enrollmentperiod`.`period_id`  AS `period_id`,
       `student_course_selection_db`.`enrollmentperiod`.`start_time` AS `start_time`,
       `student_course_selection_db`.`enrollmentperiod`.`end_time`   AS `end_time`,
       `student_course_selection_db`.`enrollmentperiod`.`is_active`  AS `is_active`,
       (case
            when (now() between `student_course_selection_db`.`enrollmentperiod`.`start_time` and `student_course_selection_db`.`enrollmentperiod`.`end_time`)
                then '进行中'
            when (now() < `student_course_selection_db`.`enrollmentperiod`.`start_time`) then '未开始'
            else '已结束' end)                                       AS `current_status`
from `student_course_selection_db`.`enrollmentperiod`
order by `student_course_selection_db`.`enrollmentperiod`.`start_time`;

