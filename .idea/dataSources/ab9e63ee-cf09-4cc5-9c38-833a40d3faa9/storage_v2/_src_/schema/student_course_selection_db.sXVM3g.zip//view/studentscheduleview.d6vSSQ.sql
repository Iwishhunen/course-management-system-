create definer = root@localhost view studentscheduleview as
select `e`.`student_id`   AS `student_id`,
       `s`.`name`         AS `student_name`,
       `c`.`course_id`    AS `course_id`,
       `c`.`course_name`  AS `course_name`,
       `sch`.`week_day`   AS `week_day`,
       `sch`.`start_time` AS `start_time`,
       `sch`.`end_time`   AS `end_time`,
       `sch`.`location`   AS `location`,
       `t`.`name`         AS `teacher_name`
from ((((`student_course_selection_db`.`enrollment` `e` join `student_course_selection_db`.`student` `s`
         on ((`e`.`student_id` = `s`.`student_id`))) join `student_course_selection_db`.`course` `c`
        on ((`e`.`course_id` = `c`.`course_id`))) join `student_course_selection_db`.`schedule` `sch`
       on ((`c`.`course_id` = `sch`.`course_id`))) join `student_course_selection_db`.`teacher` `t`
      on ((`c`.`teacher_id` = `t`.`teacher_id`)))
order by `sch`.`week_day`, `sch`.`start_time`;

