create definer = root@localhost view teachercourseview as
select `t`.`teacher_id`        AS `teacher_id`,
       `t`.`name`              AS `teacher_name`,
       `c`.`course_id`         AS `course_id`,
       `c`.`course_name`       AS `course_name`,
       `c`.`credit`            AS `credit`,
       `c`.`max_students`      AS `max_students`,
       count(`e`.`student_id`) AS `current_enrollment`,
       `sch`.`week_day`        AS `week_day`,
       `sch`.`start_time`      AS `start_time`,
       `sch`.`end_time`        AS `end_time`,
       `sch`.`location`        AS `location`
from (((`student_course_selection_db`.`teacher` `t` join `student_course_selection_db`.`course` `c`
        on ((`t`.`teacher_id` = `c`.`teacher_id`))) left join `student_course_selection_db`.`enrollment` `e`
       on ((`c`.`course_id` = `e`.`course_id`))) left join `student_course_selection_db`.`schedule` `sch`
      on ((`c`.`course_id` = `sch`.`course_id`)))
group by `t`.`teacher_id`, `c`.`course_id`, `sch`.`schedule_id`;

