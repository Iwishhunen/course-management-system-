create definer = root@localhost view coursestudentlistview as
select `c`.`course_id`       AS `course_id`,
       `c`.`course_name`     AS `course_name`,
       `e`.`student_id`      AS `student_id`,
       `s`.`name`            AS `student_name`,
       `s`.`major`           AS `major`,
       `s`.`class`           AS `class`,
       `e`.`enrollment_time` AS `enrollment_time`
from ((`student_course_selection_db`.`course` `c` join `student_course_selection_db`.`enrollment` `e`
       on ((`c`.`course_id` = `e`.`course_id`))) join `student_course_selection_db`.`student` `s`
      on ((`e`.`student_id` = `s`.`student_id`)))
order by `c`.`course_id`, `s`.`class`, `s`.`student_id`;

