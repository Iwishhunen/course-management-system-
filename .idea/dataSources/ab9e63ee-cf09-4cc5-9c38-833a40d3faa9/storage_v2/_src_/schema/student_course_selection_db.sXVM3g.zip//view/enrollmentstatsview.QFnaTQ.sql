create definer = root@localhost view enrollmentstatsview as
select `c`.`course_id`                                                            AS `course_id`,
       `c`.`course_name`                                                          AS `course_name`,
       `t`.`name`                                                                 AS `teacher_name`,
       `c`.`credit`                                                               AS `credit`,
       `c`.`max_students`                                                         AS `max_students`,
       count(`e`.`student_id`)                                                    AS `enrolled_count`,
       round(((count(`e`.`student_id`) * 100.0) / `c`.`max_students`), 2)         AS `enrollment_rate`,
       (case when (count(`e`.`student_id`) < 20) then '人数不足' else '正常' end) AS `status`
from ((`student_course_selection_db`.`course` `c` join `student_course_selection_db`.`teacher` `t`
       on ((`c`.`teacher_id` = `t`.`teacher_id`))) left join `student_course_selection_db`.`enrollment` `e`
      on ((`c`.`course_id` = `e`.`course_id`)))
group by `c`.`course_id`, `c`.`course_name`, `t`.`name`, `c`.`credit`, `c`.`max_students`
order by `enrollment_rate` desc;

