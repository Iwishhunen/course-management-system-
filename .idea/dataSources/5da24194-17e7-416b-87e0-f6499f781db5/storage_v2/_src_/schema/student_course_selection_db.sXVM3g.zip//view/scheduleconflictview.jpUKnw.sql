create definer = root@localhost view scheduleconflictview as
select `e1`.`student_id`  AS `student_id`,
       `st`.`name`        AS `student_name`,
       `c1`.`course_name` AS `course1`,
       `c2`.`course_name` AS `course2`,
       `s1`.`week_day`    AS `week_day`,
       `s1`.`start_time`  AS `start_time`,
       `s1`.`end_time`    AS `end_time`,
       `s2`.`start_time`  AS `conflict_start_time`,
       `s2`.`end_time`    AS `conflict_end_time`,
       `s1`.`location`    AS `location1`,
       `s2`.`location`    AS `location2`
from ((((((`student_course_selection_db`.`enrollment` `e1` join `student_course_selection_db`.`enrollment` `e2`
           on (((`e1`.`student_id` = `e2`.`student_id`) and
                (`e1`.`course_id` < `e2`.`course_id`)))) join `student_course_selection_db`.`schedule` `s1`
          on ((`e1`.`course_id` = `s1`.`course_id`))) join `student_course_selection_db`.`schedule` `s2`
         on ((`e2`.`course_id` = `s2`.`course_id`))) join `student_course_selection_db`.`student` `st`
        on ((`e1`.`student_id` = `st`.`student_id`))) join `student_course_selection_db`.`course` `c1`
       on ((`e1`.`course_id` = `c1`.`course_id`))) join `student_course_selection_db`.`course` `c2`
      on ((`e2`.`course_id` = `c2`.`course_id`)))
where ((`s1`.`week_day` = `s2`.`week_day`) and (`s1`.`start_time` < `s2`.`end_time`) and
       (`s1`.`end_time` > `s2`.`start_time`));

