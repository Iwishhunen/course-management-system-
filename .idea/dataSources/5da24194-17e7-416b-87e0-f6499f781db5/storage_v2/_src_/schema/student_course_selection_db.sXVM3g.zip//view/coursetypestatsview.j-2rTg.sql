create definer = root@localhost view coursetypestatsview as
select `cat`.`type_code`                AS `type_code`,
       `cat`.`type_name`                AS `type_name`,
       `cat`.`credit_requirement`       AS `credit_requirement`,
       count(distinct `c`.`course_id`)  AS `course_count`,
       ifnull(sum(`c`.`credit`), 0)     AS `total_credits`,
       count(distinct `e`.`student_id`) AS `total_enrollments`,
       round(ifnull(avg((((select count(distinct `e2`.`student_id`)
                           from `student_course_selection_db`.`enrollment` `e2`
                           where (`e2`.`course_id` = `c`.`course_id`)) * 100.0) / nullif(`c`.`max_students`, 0))), 0),
             2)                         AS `avg_enrollment_rate`
from ((`student_course_selection_db`.`course_categories` `cat` left join `student_course_selection_db`.`course` `c`
       on ((`cat`.`type_code` = `c`.`type_code`))) left join `student_course_selection_db`.`enrollment` `e`
      on ((`c`.`course_id` = `e`.`course_id`)))
group by `cat`.`type_code`, `cat`.`type_name`, `cat`.`credit_requirement`;

